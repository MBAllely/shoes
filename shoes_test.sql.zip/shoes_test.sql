--
-- Database: `shoes_test`
--
CREATE DATABASE IF NOT EXISTS `shoes_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `shoes_test`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_name` text,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `store_name` text,
  `phone` text,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `store_brand`
--

CREATE TABLE `store_brand` (
  `store_id` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `store_brand`
--

INSERT INTO `store_brand` (`store_id`, `brand_id`, `id`) VALUES
(117, 51, 1),
(126, 59, 2),
(135, 67, 3),
(144, 75, 4),
(153, 83, 5),
(162, 91, 6),
(163, 92, 7),
(163, 93, 8),
(172, 101, 9),
(173, 102, 10),
(173, 103, 11),
(183, 112, 12),
(184, 113, 13),
(184, 114, 14),
(194, 123, 15),
(195, 124, 16),
(195, 125, 17),
(133, 133, 18),
(205, 134, 19),
(206, 135, 20),
(206, 136, 21),
(144, 144, 22),
(216, 145, 23),
(217, 146, 24),
(217, 147, 25),
(218, 155, 26),
(227, 156, 27),
(228, 157, 28),
(228, 158, 29),
(229, 166, 30),
(230, 167, 31),
(231, 167, 32),
(240, 168, 33),
(241, 169, 34),
(241, 170, 35),
(242, 178, 36),
(243, 179, 37),
(244, 179, 38),
(253, 180, 39),
(254, 181, 40),
(254, 182, 41),
(255, 190, 42),
(256, 191, 43),
(257, 191, 44),
(257, 191, 45),
(266, 192, 46),
(267, 193, 47),
(267, 194, 48),
(268, 202, 49),
(269, 203, 50),
(270, 203, 51),
(271, 203, 52),
(280, 204, 53),
(281, 205, 54),
(281, 206, 55),
(282, 214, 56),
(283, 215, 57),
(284, 215, 58),
(285, 215, 59),
(294, 216, 60),
(295, 217, 61),
(295, 218, 62),
(295, 218, 63),
(296, 227, 64),
(297, 228, 65),
(298, 228, 66),
(299, 228, 67),
(308, 229, 68),
(309, 230, 69),
(309, 231, 70),
(309, 231, 71),
(310, 240, 72),
(311, 241, 73),
(312, 241, 74),
(313, 241, 75),
(322, 242, 76),
(323, 243, 77),
(323, 244, 78),
(324, 252, 79),
(325, 253, 80),
(326, 253, 81),
(327, 253, 82),
(336, 254, 83),
(337, 255, 84),
(337, 256, 85),
(337, 257, 86),
(338, 265, 87),
(339, 266, 88),
(340, 266, 89),
(341, 266, 90),
(350, 268, 91),
(351, 269, 92),
(351, 270, 93),
(351, 271, 94);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `store_brand`
--
ALTER TABLE `store_brand`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=272;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=352;
--
-- AUTO_INCREMENT for table `store_brand`
--
ALTER TABLE `store_brand`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
